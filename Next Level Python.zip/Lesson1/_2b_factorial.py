"""
Given a user's input of n, return a list of factorials from 0! to n!

Test cases:
0! = 1
1! = 1
2! = 1 x 2 = 2
4! = 1 x 2 x 3 x 4 = 24
"""


# Helper method to test equality
def equals(actual, expected):
    assert actual == expected, f'Expected {expected}, got {actual}'

# Todo: Create a function that produces the factorial of a number
def factorial(n):
    if n == 0 or n == 1:
        return 1
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result

equals(factorial(0), 1)  # Example usage of the helper method
equals(factorial(1), 1)  # Example usage of the helper method
equals(factorial(2), 2)  # Example usage of the helper method
equals(factorial(3), 6)  # Example usage of the helper method
equals(factorial(4), 24)  # Example usage of the helper method

# Todo: Test factorial function
# factorial(4)

# Todo: Request a number from the user
number = int(input('Enter a number: '))

# Todo: Print a list of factorials from 0 to the given number
for i in range(number + 1):
    print(f'{i}! = {factorial(i)}')