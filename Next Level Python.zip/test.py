person = {"name": "John", "age": 30, "city": "New York"}
print(person["name"])
print(person.get("age"))
print(person.get("City"))